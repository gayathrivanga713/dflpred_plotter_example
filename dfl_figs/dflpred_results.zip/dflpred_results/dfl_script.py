# plot_dflpred.py

protein_id = ""
sequence = ""
scores_csv = ""

import math
import matplotlib.pyplot as plt

THRESHOLD = 0.18

# Parse scores
scores = [float(x.strip()) for x in scores_csv.split(",") if x.strip() != ""]
seq = sequence.strip()
assert len(seq) == len(scores), f"Sequence length ({len(seq)}) != number of scores ({len(scores)})."

# Determine DFL calls from case 
is_dfl_case = [aa.islower() for aa in seq]
# Determine DFL calls from threshold 
is_dfl_thr = [s < THRESHOLD for s in scores]

# Quick consistency check
agree = sum(int(a == b) for a, b in zip(is_dfl_case, is_dfl_thr))
if agree != len(seq):
    print(f"Note: {len(seq)-agree} residues differ between case-annotation and threshold calls.")

# Build contiguous regions from threshold criterion
regions = []
start = None
for i, flag in enumerate(is_dfl_thr, start=1):  # 1-based indexing
    if flag and start is None:
        start = i
    if (not flag or i == len(is_dfl_thr)) and start is not None:
        end = i if flag and i == len(is_dfl_thr) else i-1
        regions.append((start, end))
        start = None

# Print summary
print(protein_id)
print(f"Length: {len(seq)} aa")
print(f"DFL threshold: {THRESHOLD}")
print("Predicted DFL regions (by threshold):")
if regions:
    for (a, b) in regions:
        frag = seq[a-1:b]
        print(f"  {a:>4}-{b:<4}  len={b-a+1:<3}  seq={frag}")
else:
    print("  none")

# Plot
x = list(range(1, len(scores)+1))
plt.figure(figsize=(10, 4.5))
plt.plot(x, scores, linewidth=1.5)
plt.axhline(THRESHOLD, linestyle="--", linewidth=1)

# Shade DFL regions (below threshold)
for a, b in regions:
    plt.axvspan(a, b, alpha=0.2)

plt.title(f"pdue_DFLpred scores – {protein_id.lstrip('>')}")
plt.xlabel("Residue number")
plt.ylabel("DFLpred score")
plt.tight_layout()
plt.savefig("pdue_dflpred_plot.png", dpi=200)
print("Saved figure: dflpred_plot.png")
plt.show()

